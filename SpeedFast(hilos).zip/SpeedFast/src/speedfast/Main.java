package speedfast;

import speedfast.controller.ZonaDeCarga;
import speedfast.model.Pedido;
import speedfast.threads.Repartidor;

public class Main {

    public static void main(String[] args) {

        ZonaDeCarga zonaDeCarga = new ZonaDeCarga();

        // Crear pedidos
        zonaDeCarga.agregarPedido(new Pedido(1, "Santiago Centro"));
        zonaDeCarga.agregarPedido(new Pedido(2, "Providencia"));
        zonaDeCarga.agregarPedido(new Pedido(3, "Pudahuel"));
        zonaDeCarga.agregarPedido(new Pedido(4, "Recoleta"));
        zonaDeCarga.agregarPedido(new Pedido(5, "Cerro Navia"));

        // Crear repartidores (hilos)
        Thread r1 = new Thread(new Repartidor("Felipe", zonaDeCarga));
        Thread r2 = new Thread(new Repartidor("Ignacio", zonaDeCarga));
        Thread r3 = new Thread(new Repartidor("Marcelo", zonaDeCarga));

        r1.start();
        r2.start();
        r3.start();

        try {
            r1.join();
            r2.join();
            r3.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println();
        System.out.println("Todos los pedidos han sido entregados correctamente.");
    }
}

