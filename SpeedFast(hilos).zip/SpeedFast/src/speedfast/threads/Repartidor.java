package speedfast.threads;

import speedfast.controller.ZonaDeCarga;
import speedfast.model.EstadoPedido;
import speedfast.model.Pedido;

public class Repartidor implements Runnable {

    private String nombre;
    private ZonaDeCarga zonaDeCarga;

    public Repartidor(String nombre, ZonaDeCarga zonaDeCarga) {
        this.nombre = nombre;
        this.zonaDeCarga = zonaDeCarga;
    }

    @Override
    public void run() {

        while (true) {

            Pedido pedido = zonaDeCarga.retirarPedido();

            if (pedido == null) {
                break; // no quedan pedidos
            }

            System.out.println("[Repartidor - " + nombre +
                    "] Retirando pedido #" + pedido.getId());

            pedido.setEstado(EstadoPedido.EN_REPARTO);
            System.out.println("[Repartidor - " + nombre +
                    "] Estado: " + pedido.getEstado());

            try {
                System.out.println("[Repartidor - " + nombre +
                        "] Entregando pedido #" + pedido.getId());
                Thread.sleep(2000); // simulación de entrega
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            pedido.setEstado(EstadoPedido.ENTREGADO);
            System.out.println("[Repartidor - " + nombre +
                    "] Estado: " + pedido.getEstado());
        }
    }
}
