package speedfast.controller;

import speedfast.model.Pedido;

import java.util.LinkedList;
import java.util.Queue;

public class ZonaDeCarga {

    private Queue<Pedido> pedidos;

    public ZonaDeCarga() {
        pedidos = new LinkedList<>();
        System.out.println("[Zona de carga inicializada]");
    }

    public synchronized void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
        System.out.println("Pedido #" + pedido.getId() +
                " agregado. Destino: " + pedido.getDireccionEntrega());
    }

    public synchronized Pedido retirarPedido() {

        if (pedidos.isEmpty()) {
            return null;
        }

        return pedidos.poll();
    }

    public synchronized boolean estaVacia() {
        return pedidos.isEmpty();
    }
}
