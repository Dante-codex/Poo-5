package speedfast.model;

public enum EstadoPedido {
    PENDIENTE,
    EN_REPARTO,
    ENTREGADO
}

