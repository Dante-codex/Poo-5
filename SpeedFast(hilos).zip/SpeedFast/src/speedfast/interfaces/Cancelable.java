package speedfast.interfaces;

public interface Cancelable {
    void cancelar();
}
