package speedfast.interfaces;

public interface Despachable {
    void despachar();
}
