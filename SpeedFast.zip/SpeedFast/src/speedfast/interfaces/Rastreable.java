package speedfast.interfaces;

public interface Rastreable {
    void verHistorial();
}

